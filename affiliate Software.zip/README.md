# Affiliate Software

Dummy AI-based affiliate software project.
