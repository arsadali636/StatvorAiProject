# Fake ML model placeholder
class DummyModel:
    def predict(self, x):
        return "Recommended Product"
